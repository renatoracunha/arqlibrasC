<?php
 
/**
 * Codifica uma string como base64 para uso em um URI CI.
 *
 * @param string $str String ou Array a ser codificado
 * @return string
 */
function verifica_arquivo (&$str = "") {
	
    
	return file_exists($str);
}

// End of file: encode_helper.php
// Location: ./system/application/helpers/encode_helper.php